import React, { useState } from "react";
import Logo from "../../src/logoGIZ.png";
import axios from "axios";
import { useNavigate } from "react-router-dom";
 export default function Login() {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [token, setToken] = useState("");

  const navigate = useNavigate();
  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await axios.post("https://localhost:7267/api/Login", {
        "username": "string",
  "password": "string"
      });

      if (response.status === 200) {
        setToken(response.data.token);
        console.log(token);
        navigate("/crud");
      }
    } catch (error) {
      console.error("An error occurred during login:", error);
    }
  };
   return (
    <div className="Login">
          
    <div className="auth-wrapper">
      <div className="auth-inner">
    <form onSubmit={handleSubmit}>
      <img className="img-logo" src={Logo} alt="React Logo" />
      <h6>
        <small className="text-muted">
          Please enter your credentials to login
        </small>
      </h6>
      <div className="mb-5">
        <label>User name</label>
        <input
          type="text"
          placeholder="Username"
          value={username}
        onChange={(e)=>setUsername(e.target.value)}
          
        />
      </div>
      <div className="mb-5 label-pd">
        <label>Password</label>
        <input
          type="password"
          placeholder="Password"
          value={password}
          onChange={(e)=>setPassword(e.target.value)}
        />
      </div>
      <div className="d-grid">
        <button type="submit" className="btn btn-primary">
          Login
        </button>
      </div>
    </form>
    </div>
    </div>
    </div>
  );
 }
